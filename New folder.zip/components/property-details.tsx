"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  MapPin,
  Bed,
  Bath,
  Square,
  Heart,
  Share2,
  Phone,
  Mail,
  Calendar,
  Car,
  Wifi,
  Shield,
  Zap,
  Trees,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

interface PropertyDetailsProps {
  propertyId: string
}

// Mock property data - in real app this would come from API
const propertyData = {
  "1": {
    id: "1",
    title: "Luxury Villa with Lake View",
    location: "East Legon, Accra",
    price: "¢450,000",
    bedrooms: 4,
    bathrooms: 3,
    area: "3,200 sq ft",
    type: "Villa",
    featured: true,
    images: [
      "/luxury-villa-with-lake-view-ghana.png",
      "/luxury-villa-interior-1.png",
      "/luxury-villa-interior-2.png",
      "/luxury-villa-exterior.png",
    ],
    description:
      "This stunning lakefront villa offers the perfect blend of luxury and tranquility. Situated in the prestigious East Legon area, this property features breathtaking lake views, modern amenities, and spacious living areas perfect for entertaining. The villa boasts high-end finishes throughout, including marble countertops, hardwood floors, and custom cabinetry.",
    features: [
      "Lake view from all major rooms",
      "Private dock and boat access",
      "Gourmet kitchen with premium appliances",
      "Master suite with walk-in closet",
      "Home office/study room",
      "Landscaped gardens",
      "Swimming pool and outdoor entertainment area",
      "24/7 security",
    ],
    amenities: [
      { icon: Car, label: "2-Car Garage" },
      { icon: Wifi, label: "High-Speed Internet" },
      { icon: Shield, label: "24/7 Security" },
      { icon: Zap, label: "Backup Generator" },
      { icon: Trees, label: "Landscaped Garden" },
    ],
    agent: {
      name: "Akosua Mensah",
      title: "Senior Property Consultant",
      phone: "+233 24 234 5678",
      email: "akosua@lakesideestate.com",
      image: "/team-akosua-mensah-sales.png",
    },
    yearBuilt: 2020,
    propertyId: "LE-001",
    status: "Available",
  },
}

export default function PropertyDetails({ propertyId }: PropertyDetailsProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const property = propertyData[propertyId as keyof typeof propertyData]

  if (!property) {
    return <div className="py-16 text-center">Property not found</div>
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length)
  }

  return (
    <div className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Image Gallery */}
            <div className="relative">
              <div className="relative h-96 rounded-lg overflow-hidden">
                <img
                  src={property.images[currentImageIndex] || "/placeholder.svg"}
                  alt={property.title}
                  className="w-full h-full object-cover"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-background/80 hover:bg-background"
                  onClick={prevImage}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-background/80 hover:bg-background"
                  onClick={nextImage}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                  {property.images.map((_, index) => (
                    <button
                      key={index}
                      className={`w-2 h-2 rounded-full ${
                        index === currentImageIndex ? "bg-primary" : "bg-background/60"
                      }`}
                      onClick={() => setCurrentImageIndex(index)}
                    />
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-4 gap-2 mt-4">
                {property.images.slice(0, 4).map((image, index) => (
                  <button
                    key={index}
                    className={`relative h-20 rounded-md overflow-hidden ${
                      index === currentImageIndex ? "ring-2 ring-primary" : ""
                    }`}
                    onClick={() => setCurrentImageIndex(index)}
                  >
                    <img src={image || "/placeholder.svg"} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Property Info */}
            <div>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-primary text-primary-foreground">Featured</Badge>
                    <Badge variant="secondary">{property.type}</Badge>
                    <Badge variant="outline">{property.status}</Badge>
                  </div>
                  <h1 className="text-3xl font-bold text-foreground mb-2 text-balance">{property.title}</h1>
                  <div className="flex items-center text-muted-foreground mb-2">
                    <MapPin className="w-5 h-5 mr-2" />
                    {property.location}
                  </div>
                  <div className="text-3xl font-bold text-primary">{property.price}</div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Heart className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-card rounded-lg">
                  <Bed className="w-6 h-6 mx-auto mb-2 text-primary" />
                  <div className="font-semibold">{property.bedrooms}</div>
                  <div className="text-sm text-muted-foreground">Bedrooms</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <Bath className="w-6 h-6 mx-auto mb-2 text-primary" />
                  <div className="font-semibold">{property.bathrooms}</div>
                  <div className="text-sm text-muted-foreground">Bathrooms</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <Square className="w-6 h-6 mx-auto mb-2 text-primary" />
                  <div className="font-semibold">{property.area}</div>
                  <div className="text-sm text-muted-foreground">Area</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <Calendar className="w-6 h-6 mx-auto mb-2 text-primary" />
                  <div className="font-semibold">{property.yearBuilt}</div>
                  <div className="text-sm text-muted-foreground">Year Built</div>
                </div>
              </div>

              <Separator className="my-6" />

              <div>
                <h2 className="text-2xl font-semibold text-foreground mb-4">Description</h2>
                <p className="text-muted-foreground font-[family-name:var(--font-body)] text-pretty leading-relaxed">
                  {property.description}
                </p>
              </div>

              <Separator className="my-6" />

              <div>
                <h2 className="text-2xl font-semibold text-foreground mb-4">Key Features</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {property.features.map((feature, index) => (
                    <div key={index} className="flex items-center">
                      <div className="w-2 h-2 bg-primary rounded-full mr-3" />
                      <span className="text-muted-foreground font-[family-name:var(--font-body)]">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="my-6" />

              <div>
                <h2 className="text-2xl font-semibold text-foreground mb-4">Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {property.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center p-3 bg-card rounded-lg">
                      <amenity.icon className="w-5 h-5 text-primary mr-3" />
                      <span className="text-sm font-[family-name:var(--font-body)]">{amenity.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Agent Contact */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Contact Agent</h3>
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={property.agent.image || "/placeholder.svg"}
                    alt={property.agent.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-foreground">{property.agent.name}</div>
                    <div className="text-sm text-muted-foreground">{property.agent.title}</div>
                  </div>
                </div>
                <div className="space-y-3">
                  <Button className="w-full">
                    <Phone className="w-4 h-4 mr-2" />
                    Call Now
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Mail className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Calendar className="w-4 h-4 mr-2" />
                    Schedule Viewing
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Property Details */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Property Details</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Property ID:</span>
                    <span className="font-medium">{property.propertyId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Type:</span>
                    <span className="font-medium">{property.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Year Built:</span>
                    <span className="font-medium">{property.yearBuilt}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <span className="font-medium">{property.status}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
