import Navigation from "@/components/navigation"
import PropertyDetails from "@/components/property-details"
import RelatedProperties from "@/components/related-properties"
import Footer from "@/components/footer"

interface PropertyPageProps {
  params: {
    id: string
  }
}

export default function PropertyPage({ params }: PropertyPageProps) {
  return (
    <main className="min-h-screen">
      <Navigation />
      <PropertyDetails propertyId={params.id} />
      <RelatedProperties currentPropertyId={params.id} />
      <Footer />
    </main>
  )
}
